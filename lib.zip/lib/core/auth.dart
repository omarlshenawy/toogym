import 'dart:convert';

import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'constants.dart';
import 'storage.dart';
import '../api/auth_api.dart';

class AuthUser {
  final String id;
  final String username;
  final String role;
  final String status;
  final String? firstName;
  final String? lastName;
  final String? gymId;

  const AuthUser({
    required this.id,
    required this.username,
    required this.role,
    required this.status,
    this.firstName,
    this.lastName,
    this.gymId,
  });

  factory AuthUser.fromJson(Map<String, dynamic> json) {
    return AuthUser(
      id: json['id']?.toString() ?? '',
      username: json['username']?.toString() ?? '',
      role: json['role']?.toString() ?? '',
      status: json['status']?.toString() ?? '',
      firstName: json['first_name']?.toString(),
      lastName: json['last_name']?.toString(),
      gymId: json['gym_id']?.toString(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'username': username,
      'role': role,
      'status': status,
      'first_name': firstName,
      'last_name': lastName,
      'gym_id': gymId,
    };
  }

  String get displayName {
    final name = [
      firstName,
      lastName,
    ].where((value) => value != null && value!.isNotEmpty).join(' ');

    return name.isNotEmpty ? name : username;
  }

  bool get isSaasAdmin => role == 'saas_admin';

  bool get isGymAdmin => role == 'gym_admin';

  bool get isStaff => role == 'staff';
}

enum AuthStatus {
  unknown,
  authenticated,
  unauthenticated,
  loading,
}

class AuthState {
  final AuthStatus status;
  final AuthUser? user;
  final String? error;

  const AuthState({
    required this.status,
    this.user,
    this.error,
  });

  const AuthState.unknown()
      : status = AuthStatus.unknown,
        user = null,
        error = null;

  const AuthState.authenticated(AuthUser user)
      : status = AuthStatus.authenticated,
        user = user,
        error = null;

  const AuthState.unauthenticated()
      : status = AuthStatus.unauthenticated,
        user = null,
        error = null;

  const AuthState.loading()
      : status = AuthStatus.loading,
        user = null,
        error = null;

  AuthState failure(String message) {
    return AuthState(
      status: AuthStatus.unauthenticated,
      user: user,
      error: message,
    );
  }

  bool get isAuthenticated =>
      status == AuthStatus.authenticated && user != null;
}

class AuthController extends StateNotifier<AuthState> {
  AuthController() : super(const AuthState.unknown()) {
    restoreSession();
  }

  Future<void> restoreSession() async {
    final token = AppStorage.getString(
      AppConstants.accessTokenKey,
    );

    final storedUser = AppStorage.getJson(
      AppConstants.userKey,
    );

    if (token == null ||
        token.isEmpty ||
        storedUser == null) {
      state = const AuthState.unauthenticated();
      return;
    }

    try {
      final localUser = AuthUser.fromJson(storedUser);

      state = AuthState.authenticated(localUser);

      // Verify the token against the backend.
      try {
        final remoteUser = await AuthApi.me();

        await _saveUser(remoteUser);

        state = AuthState.authenticated(remoteUser);
      } catch (_) {
        await logout(localOnly: true);
      }
    } catch (_) {
      await logout(localOnly: true);
    }
  }

  Future<AuthUser?> login({
    required String username,
    required String password,
  }) async {
    state = const AuthState.loading();

    try {
      final response = await AuthApi.login(
        username: username,
        password: password,
      );

      final token = response['access_token']?.toString();

      final userData = response['user'];

      if (token == null ||
          token.isEmpty ||
          userData is! Map<String, dynamic>) {
        state = const AuthState.unauthenticated();

        throw Exception(
          'Invalid login response from server.',
        );
      }

      final authenticatedUser = AuthUser.fromJson(userData);

      await AppStorage.setString(
        AppConstants.accessTokenKey,
        token,
      );

      await _saveUser(authenticatedUser);

      state = AuthState.authenticated(
        authenticatedUser,
      );

      return authenticatedUser;
    } catch (e) {
      state = AuthState(
        status: AuthStatus.unauthenticated,
        error: e.toString(),
      );

      rethrow;
    }
  }

  Future<void> logout({
    bool localOnly = false,
  }) async {
    if (!localOnly) {
      try {
        await AuthApi.logout();
      } catch (_) {
        // Logout should still clear the local session
        // if the server request fails.
      }
    }

    await AppStorage.remove(
      AppConstants.accessTokenKey,
    );

    await AppStorage.remove(
      AppConstants.userKey,
    );

    state = const AuthState.unauthenticated();
  }

  Future<void> _saveUser(AuthUser user) async {
    await AppStorage.setString(
      AppConstants.userKey,
      jsonEncode(user.toJson()),
    );
  }
}

final authProvider =
StateNotifierProvider<AuthController, AuthState>(
      (ref) {
    return AuthController();
  },
);