import 'dart:ui' as html;

import 'package:flutter/material.dart';

import '../../core/common_widgets.dart';
import '../../core/constants.dart';
import '../../core/responsive.dart';

class SupportPage extends StatelessWidget {
  const SupportPage({
    super.key,
  });

  void _openApiDocs() {
    html.window.open(
      '${AppConstants.apiBaseUrl}/docs',
      '_blank',
    );
  }

  @override
  Widget build(BuildContext context) {
    final mobile =
    Responsive.isMobile(context);

    return SingleChildScrollView(
      padding: EdgeInsets.all(
        mobile ? 16 : 24,
      ),
      child: Column(
        crossAxisAlignment:
        CrossAxisAlignment.start,
        children: [
          const AppPageHeader(
            title: 'Support',
            subtitle:
            'GymFlow Pro API support.',
          ),

          const SizedBox(height: 24),

          Card(
            child: Padding(
              padding:
              const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment:
                CrossAxisAlignment.start,
                children: [
                  Text(
                    'Need help?',
                    style:
                    Theme.of(context)
                        .textTheme
                        .titleLarge
                        ?.copyWith(
                      fontWeight:
                      FontWeight.w700,
                    ),
                  ),

                  const SizedBox(
                    height: 12,
                  ),

                  const Text(
                    'Use the API documentation to inspect every endpoint and schema.',
                  ),

                  const SizedBox(
                    height: 20,
                  ),

                  SelectableText(
                    '${AppConstants.apiBaseUrl}/docs',
                    style:
                    Theme.of(context)
                        .textTheme
                        .bodyMedium,
                  ),

                  const SizedBox(
                    height: 20,
                  ),

                  ElevatedButton.icon(
                    onPressed:
                    _openApiDocs,
                    icon: const Icon(
                      Icons
                          .open_in_new_outlined,
                    ),
                    label:
                    const Text(
                      'Open API Docs',
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}